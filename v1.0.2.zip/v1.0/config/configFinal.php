<?php
define("ROOT", 'http://localhost/GoofyStoreRespaldos/v1.0/');
define("SHORTROOT", '//localhost/GoofyStoreRespaldos/v1.0/');
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = 'pruebanews';